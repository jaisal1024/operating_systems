#include "common.h"

// int verbose = ALL:
// int debug = DEBUG;
// int warning = NONE;
int verbose = NONE;
