#include "common.h"

// int verbose = ALL:
// int warning
// int warning = NONE;
int verbose = NONE;
